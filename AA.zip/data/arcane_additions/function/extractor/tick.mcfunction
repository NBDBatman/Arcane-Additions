# Runs "as and at" each Enchant Extractor marker every tick (hooked from the
# main tick.mcfunction). The lectern sits at ~-0.5 ~-1.05 ~-0.5 relative to
# the marker (see summon_marker.mcfunction for the inverse offset).

execute unless block ~-0.5 ~-1.05 ~-0.5 minecraft:lectern run function arcane_additions:extractor/despawn_marker

# An extraction is already in progress: watch for the player picking one of
# the floating enchant-book choices.
execute if block ~-0.5 ~-1.05 ~-0.5 minecraft:lectern as @e[tag=arcane_additions.extract_source,distance=..2] at @s run function arcane_additions:extractor/watch_choices

# No extraction in progress: look for a freshly dropped enchanted item placed
# on the extractor.
execute if block ~-0.5 ~-1.05 ~-0.5 minecraft:lectern unless entity @e[tag=arcane_additions.extract_source,distance=..2] as @e[type=item,distance=..1.5] at @s if data entity @s Item.components."minecraft:enchantments" run function arcane_additions:extractor/begin_extraction
